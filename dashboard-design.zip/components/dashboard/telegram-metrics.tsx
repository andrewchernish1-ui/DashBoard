"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, Eye, TrendingUp, TrendingDown } from "lucide-react"
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

const subscribersData = [
  { day: "Пн", value: 2340 },
  { day: "Вт", value: 2355 },
  { day: "Ср", value: 2380 },
  { day: "Чт", value: 2410 },
  { day: "Пт", value: 2445 },
  { day: "Сб", value: 2480 },
  { day: "Вс", value: 2520 },
]

const viewsData = [
  { day: "Пн", value: 12400 },
  { day: "Вт", value: 15600 },
  { day: "Ср", value: 14200 },
  { day: "Чт", value: 18900 },
  { day: "Пт", value: 16700 },
  { day: "Сб", value: 21300 },
  { day: "Вс", value: 19800 },
]

const metrics = [
  {
    label: "Подписчики",
    icon: Users,
    today: 42,
    week: 180,
    month: 720,
    change: 12.5,
    color: "bg-blue-500",
  },
  {
    label: "Просмотры",
    icon: Eye,
    today: 3200,
    week: 18900,
    month: 78400,
    change: 8.3,
    color: "bg-teal-500",
  },
]

export function TelegramMetrics() {
  return (
    <Card className="col-span-1">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center">
            <span className="text-blue-600 text-sm">📱</span>
          </div>
          Telegram-канал
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {metrics.map((metric) => (
          <div key={metric.label} className="p-3 rounded-xl bg-muted/50 border border-border">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <div className={`w-8 h-8 rounded-lg ${metric.color} bg-opacity-20 flex items-center justify-center`}>
                  <metric.icon
                    className={`w-4 h-4 ${metric.color === "bg-blue-500" ? "text-blue-500" : "text-teal-500"}`}
                  />
                </div>
                <span className="font-medium text-sm">{metric.label}</span>
              </div>
              <div className="flex items-center gap-1">
                {metric.change > 0 ? (
                  <TrendingUp className="w-3 h-3 text-emerald-500" />
                ) : (
                  <TrendingDown className="w-3 h-3 text-red-500" />
                )}
                <span className={`text-xs font-medium ${metric.change > 0 ? "text-emerald-500" : "text-red-500"}`}>
                  +{metric.change}%
                </span>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-2 text-center">
              <div>
                <p className="text-lg font-bold text-foreground">{metric.today.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">Сегодня</p>
              </div>
              <div>
                <p className="text-lg font-bold text-foreground">{metric.week.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">Неделя</p>
              </div>
              <div>
                <p className="text-lg font-bold text-foreground">{metric.month.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">Месяц</p>
              </div>
            </div>
          </div>
        ))}

        <div className="space-y-3">
          <p className="text-sm font-medium text-muted-foreground">Подписчики за неделю</p>
          <div className="h-24">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={subscribersData}>
                <defs>
                  <linearGradient id="subscribersGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="day" tick={{ fontSize: 10 }} stroke="#9ca3af" />
                <YAxis tick={{ fontSize: 10 }} stroke="#9ca3af" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "white",
                    border: "1px solid #e5e7eb",
                    borderRadius: "8px",
                    fontSize: "12px",
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="value"
                  stroke="#3b82f6"
                  fill="url(#subscribersGradient)"
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="space-y-3">
          <p className="text-sm font-medium text-muted-foreground">Просмотры за неделю</p>
          <div className="h-24">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={viewsData}>
                <defs>
                  <linearGradient id="viewsGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#14b8a6" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#14b8a6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="day" tick={{ fontSize: 10 }} stroke="#9ca3af" />
                <YAxis tick={{ fontSize: 10 }} stroke="#9ca3af" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "white",
                    border: "1px solid #e5e7eb",
                    borderRadius: "8px",
                    fontSize: "12px",
                  }}
                />
                <Area type="monotone" dataKey="value" stroke="#14b8a6" fill="url(#viewsGradient)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
