"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, TrendingDown } from "lucide-react"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

const exerciseData = [
  { name: "Clean", current: 120, previous: 115, change: 4.3 },
  { name: "Snatch", current: 95, previous: 90, change: 5.6 },
  { name: "Deadlift", current: 180, previous: 175, change: 2.9 },
  { name: "Squat", current: 160, previous: 155, change: 3.2 },
  { name: "Press", current: 75, previous: 72, change: 4.2 },
]

const progressData = [
  { month: "Июль", clean: 105, snatch: 80, deadlift: 160, squat: 140 },
  { month: "Авг", clean: 108, snatch: 82, deadlift: 165, squat: 145 },
  { month: "Сен", clean: 112, snatch: 85, deadlift: 170, squat: 150 },
  { month: "Окт", clean: 115, snatch: 88, deadlift: 172, squat: 152 },
  { month: "Ноя", clean: 118, snatch: 92, deadlift: 177, squat: 157 },
  { month: "Дек", clean: 120, snatch: 95, deadlift: 180, squat: 160 },
]

export function ExerciseRM() {
  return (
    <Card className="col-span-1">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center">
            <span className="text-emerald-600 text-sm">🏋️</span>
          </div>
          Повторные максимумы (RM)
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          {exerciseData.slice(0, 4).map((exercise) => (
            <div key={exercise.name} className="p-3 rounded-xl bg-muted/50 border border-border">
              <p className="text-xs text-muted-foreground mb-1">{exercise.name}</p>
              <p className="text-xl font-bold text-foreground">{exercise.current} кг</p>
              <div className="flex items-center gap-1 mt-1">
                {exercise.change > 0 ? (
                  <TrendingUp className="w-3 h-3 text-emerald-500" />
                ) : (
                  <TrendingDown className="w-3 h-3 text-red-500" />
                )}
                <span className={`text-xs font-medium ${exercise.change > 0 ? "text-emerald-500" : "text-red-500"}`}>
                  {exercise.change > 0 ? "+" : ""}
                  {exercise.change}%
                </span>
              </div>
            </div>
          ))}
        </div>

        <div className="h-48">
          <p className="text-sm font-medium text-muted-foreground mb-2">Прогресс за 6 месяцев</p>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={progressData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="month" tick={{ fontSize: 11 }} stroke="#9ca3af" />
              <YAxis tick={{ fontSize: 11 }} stroke="#9ca3af" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "white",
                  border: "1px solid #e5e7eb",
                  borderRadius: "8px",
                  fontSize: "12px",
                }}
              />
              <Line type="monotone" dataKey="clean" stroke="#10b981" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="snatch" stroke="#3b82f6" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="deadlift" stroke="#f59e0b" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="squat" stroke="#8b5cf6" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="flex flex-wrap gap-3 text-xs">
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 rounded-full bg-emerald-500" />
            <span>Clean</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 rounded-full bg-blue-500" />
            <span>Snatch</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 rounded-full bg-amber-500" />
            <span>Deadlift</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 rounded-full bg-violet-500" />
            <span>Squat</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
