"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { AlertCircle, Clock, CheckCircle, CalendarDays } from "lucide-react"

const clients = [
  {
    id: 1,
    name: "Александр Иванов",
    nextPayment: "2025-12-10",
    subscriptionEnd: "2025-12-10",
    amount: 5000,
    status: "urgent", // urgent, warning, ok
    plan: "Премиум",
  },
  {
    id: 2,
    name: "Мария Петрова",
    nextPayment: "2025-12-15",
    subscriptionEnd: "2025-12-15",
    amount: 3500,
    status: "warning",
    plan: "Стандарт",
  },
  {
    id: 3,
    name: "Дмитрий Сидоров",
    nextPayment: "2025-12-22",
    subscriptionEnd: "2025-12-22",
    amount: 5000,
    status: "ok",
    plan: "Премиум",
  },
  {
    id: 4,
    name: "Елена Козлова",
    nextPayment: "2025-12-28",
    subscriptionEnd: "2025-12-28",
    amount: 3500,
    status: "ok",
    plan: "Стандарт",
  },
  {
    id: 5,
    name: "Сергей Новиков",
    nextPayment: "2026-01-05",
    subscriptionEnd: "2026-01-05",
    amount: 7000,
    status: "ok",
    plan: "VIP",
  },
]

function getStatusConfig(status: string) {
  switch (status) {
    case "urgent":
      return {
        icon: AlertCircle,
        color: "text-red-500",
        bg: "bg-red-50",
        badge: "destructive" as const,
        label: "Срочно",
      }
    case "warning":
      return {
        icon: Clock,
        color: "text-amber-500",
        bg: "bg-amber-50",
        badge: "secondary" as const,
        label: "Скоро",
      }
    default:
      return {
        icon: CheckCircle,
        color: "text-emerald-500",
        bg: "bg-emerald-50",
        badge: "outline" as const,
        label: "Норма",
      }
  }
}

function formatDate(dateString: string) {
  const date = new Date(dateString)
  return date.toLocaleDateString("ru-RU", { day: "numeric", month: "short" })
}

function getDaysUntil(dateString: string) {
  const date = new Date(dateString)
  const today = new Date()
  const diffTime = date.getTime() - today.getTime()
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
  return diffDays
}

export function PaymentTracking() {
  const urgentCount = clients.filter((c) => c.status === "urgent").length
  const warningCount = clients.filter((c) => c.status === "warning").length
  const totalExpected = clients.reduce((acc, c) => acc + c.amount, 0)

  return (
    <Card className="col-span-1">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-amber-100 flex items-center justify-center">
            <span className="text-amber-600 text-sm">💳</span>
          </div>
          Оплаты клиентов
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-3 gap-3">
          <div className="p-3 rounded-xl bg-red-50 border border-red-100 text-center">
            <p className="text-2xl font-bold text-red-600">{urgentCount}</p>
            <p className="text-xs text-red-600">Срочно</p>
          </div>
          <div className="p-3 rounded-xl bg-amber-50 border border-amber-100 text-center">
            <p className="text-2xl font-bold text-amber-600">{warningCount}</p>
            <p className="text-xs text-amber-600">На этой неделе</p>
          </div>
          <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-100 text-center">
            <p className="text-2xl font-bold text-emerald-600">{(totalExpected / 1000).toFixed(0)}к</p>
            <p className="text-xs text-emerald-600">Ожидается ₽</p>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium text-muted-foreground">Напоминания о продлении</p>
            <Badge variant="secondary" className="text-xs">
              {clients.length} клиентов
            </Badge>
          </div>

          <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
            {clients.map((client) => {
              const statusConfig = getStatusConfig(client.status)
              const daysUntil = getDaysUntil(client.nextPayment)

              return (
                <div key={client.id} className={`p-3 rounded-xl border ${statusConfig.bg} border-opacity-50`}>
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <statusConfig.icon className={`w-4 h-4 ${statusConfig.color}`} />
                      <span className="font-medium text-sm text-foreground">{client.name}</span>
                    </div>
                    <Badge variant={statusConfig.badge} className="text-xs">
                      {statusConfig.label}
                    </Badge>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <CalendarDays className="w-3 h-3" />
                      <span>Оплата: {formatDate(client.nextPayment)}</span>
                    </div>
                    <div className="text-right">
                      <span className="font-medium text-foreground">{client.amount.toLocaleString()} ₽</span>
                    </div>
                    <div className="text-muted-foreground">
                      <span>План: {client.plan}</span>
                    </div>
                    <div className="text-right">
                      <span
                        className={`font-medium ${daysUntil <= 3 ? "text-red-500" : daysUntil <= 7 ? "text-amber-500" : "text-muted-foreground"}`}
                      >
                        {daysUntil > 0 ? `Через ${daysUntil} дн.` : "Сегодня"}
                      </span>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
