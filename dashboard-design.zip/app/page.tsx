import { Sidebar } from "@/components/dashboard/sidebar"
import { Header } from "@/components/dashboard/header"
import { ExerciseRM } from "@/components/dashboard/exercise-rm"
import { TelegramMetrics } from "@/components/dashboard/telegram-metrics"
import { PaymentTracking } from "@/components/dashboard/payment-tracking"

export default function Dashboard() {
  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col">
        <Header />
        <main className="flex-1 p-6 overflow-auto">
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
            <ExerciseRM />
            <TelegramMetrics />
            <PaymentTracking />
          </div>
        </main>
      </div>
    </div>
  )
}
